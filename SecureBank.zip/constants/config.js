export const API_KEYS = {
  firebase: 'FAKE_FIREBASE_KEY_123456',
  paymentGateway: 'sk_test_hardcoded_key',
};

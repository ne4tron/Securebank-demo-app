import React, { useEffect, useState } from 'react';
import { View, Text } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function DashboardScreen() {
  const [userInfo, setUserInfo] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      const data = await AsyncStorage.getItem('userInfo');
      if (!data) {
        await AsyncStorage.setItem('userInfo', JSON.stringify({
          name: 'John Doe',
          balance: '10,000 USD',
        }));
      }
      setUserInfo(JSON.parse(data || '{}'));
    };

    fetchUser();
  }, []);

  return (
    <View>
      <Text>Welcome, {userInfo?.name}</Text>
      <Text>Balance: {userInfo?.balance}</Text>
    </View>
  );
}

import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const hardcodedUsername = 'admin';
const hardcodedPassword = 'password123';

export default function LoginScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const login = () => {
    if (username === hardcodedUsername && password === hardcodedPassword) {
      AsyncStorage.setItem('userToken', 'dummy-auth-token');
      navigation.navigate('Dashboard');
    } else {
      Alert.alert('Login failed');
    }
  };

  return (
    <View>
      <Text>Username:</Text>
      <TextInput value={username} onChangeText={setUsername} />
      <Text>Password:</Text>
      <TextInput value={password} onChangeText={setPassword} secureTextEntry />
      <Button title="Login" onPress={login} />
    </View>
  );
}

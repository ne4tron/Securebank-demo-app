export default function isDeviceJailbroken() {
  return false;
}

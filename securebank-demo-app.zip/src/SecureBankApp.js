import React, { useState } from 'react';

export default function SecureBankApp() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userInfo] = useState({
    name: "John Doe",
    accountId: "1234567890",
    balance: "$12,345.67"
  });

  const login = () => {
    setIsLoggedIn(true);
  };

  return (
    <div style={{ padding: '2rem', maxWidth: '400px', margin: 'auto' }}>
      {!isLoggedIn ? (
        <div style={{ background: '#fff', padding: '1rem', borderRadius: '1rem', boxShadow: '0 4px 10px rgba(0,0,0,0.1)' }}>
          <h2>SecureBank Login</h2>
          <p>Username: demo_user</p>
          <p>Password: password123</p>
          <button onClick={login} style={{ width: '100%', padding: '0.5rem' }}>Login</button>
        </div>
      ) : (
        <div style={{ background: '#fff', padding: '1rem', borderRadius: '1rem', boxShadow: '0 4px 10px rgba(0,0,0,0.1)' }}>
          <h2>Welcome, {userInfo.name}</h2>
          <p>Account ID: {userInfo.accountId}</p>
          <p>Balance: {userInfo.balance}</p>
          <p style={{ fontSize: '0.75rem', color: 'red' }}>* User info stored in plaintext for demo purposes</p>
        </div>
      )}
    </div>
  );
}